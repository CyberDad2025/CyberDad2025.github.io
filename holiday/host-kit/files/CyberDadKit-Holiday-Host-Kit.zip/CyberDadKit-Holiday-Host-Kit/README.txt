CyberDadKit | Holiday Host Kit
Four printable holiday packs, one folder each. Each pack is included once.

01-Gather-and-Play/              16 pages, 12 games. US-Letter/ and A4/, Color and Low-Ink
02-Christmas-Trivia-Night/       18 pages, 8 rounds, 80 questions. US-Letter/ and A4/, Color and Low-Ink
03-Thanksgiving-Host-Dinner-Planner/  18 print pages: US-Letter/ and A4/, Color and Low-Ink
                                 19-page tablet edition: Tablet/
04-Kids-Table-Activity-Pack/     18 pages, 14 activities. US-Letter/ and A4/, Color and Low-Ink

Every edition of a pack has the same content. Use the folder that matches your paper.
Start with the host page of each pack (page 2 in the print editions; page 3 in the planner's tablet edition, after the index). Keep answer-key pages with the host.
Print portrait, single-sided, at 100% / Actual size. A physical print test has not been
performed. Print a test page first.

Each pack's host page shows that pack's own refund text (page 2 in the print editions; page 3 in the planner's tablet edition).
Your Holiday Host Kit purchase is covered by the Holiday Host Kit refund policy: full refund for any reason within 7 days of
your purchase date. Email ruel@getcyberdadkit.com with the email address used for purchase
and your order reference.

Personal, noncommercial use, including internal office use. Do not resell, rehost or
distribute these files.
Support: ruel@getcyberdadkit.com
CyberDad Kit LLC, PO Box 940061, Maitland, FL 32794
